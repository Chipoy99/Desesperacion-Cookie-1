# hello-world
Yes, I am new and lack at programing
I want to get pro in programming, and I want to develop cool proyects for the sake of humanity
